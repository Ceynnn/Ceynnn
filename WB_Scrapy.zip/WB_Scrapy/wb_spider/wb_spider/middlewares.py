# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html
import json
import os

from scrapy import signals

from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By


# useful for handling different item types with a single interface
from itemadapter import is_item, ItemAdapter


class WbSpiderSpiderMiddleware:
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the spider middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_spider_input(self, response, spider):

        # Called for each response that goes through the spider
        # middleware and into the spider.

        # Should return None or raise an exception.
        return None

    def process_spider_output(self, response, result, spider):
        # Called with the results returned from the Spider, after
        # it has processed the response.

        # Must return an iterable of Request, or item objects.
        for i in result:
            yield i

    def process_spider_exception(self, response, exception, spider):
        # Called when a spider or process_spider_input() method
        # (from other spider middleware) raises an exception.

        # Should return either None or an iterable of Request or item objects.
        pass

    def process_start_requests(self, start_requests, spider):

        # Called with the start requests of the spider, and works
        # similarly to the process_spider_output() method, except
        # that it doesn’t have a response associated.

        # Must return only requests (not items).
        for r in start_requests:
            yield r

    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)


class WbSpiderDownloaderMiddleware:
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the downloader middleware does not modify the
    # passed objects.
    def __init__(self):
        print('下载中间件启动')
        self.get_cookie()

    def get_cookie(self):
        options = webdriver.ChromeOptions()

        options.add_argument('lang=zh_CN.UTF-8')
        if 'wei_cookies.txt' in os.listdir():
            options.add_argument('--headless')
            options.add_argument('--disable-gpu')
        self.driver = webdriver.Chrome('chromedriver.exe', chrome_options=options)
        self.driver.get('https://weibo.com/login.php')
        if 'wei_cookies.txt' not in os.listdir():
            self.cookies = self.save_cook()
        self.cookies =self.read_cookies()
        self.driver.quit()
        self.cookies = {i["name"]:i["value"] for i in self.cookies}



    def save_cook(self):  # 保存Cookies函数 未登录需要扫码登录下 保存登录信息共下次使用
        self.withing_function('classname', 'woo-badge-box')
        name = self.driver.find_element_by_xpath('//div[@class="woo-box-flex woo-box-alignCenter woo-box-justifyCenter Ctrls_item_3KzNH Ctrls_avatarItem_3LrJN"]').get_attribute("title")
        print("{}登录成功！".format(name))
        cookies = self.driver.get_cookies()
        with open("wei_cookies.txt", "w") as fp:
            json.dump(cookies, fp)
        return cookies

    # 以有Cookies则直接登录
    def read_cookies(self):
        with open("wei_cookies.txt", "r") as fp:
            cookies = json.load(fp)
            for cookie in cookies:
                self.driver.add_cookie(cookie)
        # self.driver.get("https://weibo.com/")
        # self.withing_function('classname', 'woo-badge-box')
        # name = self.driver.find_element_by_xpath('//div[@class="woo-box-flex woo-box-alignCenter woo-box-justifyCenter Ctrls_item_3KzNH Ctrls_avatarItem_3LrJN"]').get_attribute("title")
        # print("{}登录成功！".format(name))
        return cookies

    # 等待函数 为浏览器设置等待
    def withing_function(self, key, value):  # W_person_info
        if key == 'classname':
            WebDriverWait(self.driver, 180, 0.5).until(EC.presence_of_element_located(
                (By.CLASS_NAME, value)))
        elif key == 'id':
            WebDriverWait(self.driver, 180, 0.5).until(EC.presence_of_element_located(
                (By.ID, value)))

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_request(self, request, spider):
        print(request)
        # print(self.cookies)
        request.cookies = self.cookies
        # Called for each request that goes through the downloader
        # middleware.

        # Must either:
        # - return None: continue processing this request
        # - or return a Response object
        # - or return a Request object
        # - or raise IgnoreRequest: process_exception() methods of
        #   installed downloader middleware will be called
        return None

    def process_response(self, request, response, spider):
        # Called with the response returned from the downloader.

        # Must either;
        # - return a Response object
        # - return a Request object
        # - or raise IgnoreRequest
        return response

    def process_exception(self, request, exception, spider):
        # Called when a download handler or a process_request()
        # (from other downloader middleware) raises an exception.

        # Must either:
        # - return None: continue processing this exception
        # - return a Response object: stops process_exception() chain
        # - return a Request object: stops process_exception() chain
        pass

    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)
