import json

import scrapy
from wb_spider.MyUA import get_ua

class WbspiderSpider(scrapy.Spider):
    name = 'wbspider'
    allowed_domains = ['weibo.com']
    #start_urls = ['http://weibo.com/']

    def start_requests(self):
       start_url="https://weibo.com/ajax/search/all?containerid=100103type%3D1%26q%3D%E4%B8%8A%E6%B5%B7%E7%89%B9%E6%96%AF%E6%8B%89%E4%BA%8B%E4%BB%B6%26t%3D1&page={}&count=20"
       for page in range(1,40):
           url = start_url.format(page)
           yield scrapy.FormRequest(
               url=url,
               headers={
                   'User-Agent': "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                   "x-xsrf-token": "VKpz1KXPsFfsZL0v6cgau8Fl",
                   "x-requested-with": "XMLHttpRequest",
               },
               callback=self.parse_wbList,
               #meta={"From": "玄武区-玄武动态", "current_Page": 0},
           )


    def parse_wbList(self, response):
        print(response)
        json_data = json.loads(response.text)
        #print(json_data)
        if json_data['ok']==1:
            wbCards = json_data["data"]["cards"]
            for card in wbCards:
                if card["card_type"] == 11:
                    card_groups = card["card_group"]
                    for card_group in card_groups:
                        mblog = card_group.get("mblog",None)
                        if mblog:
                            comments_count = mblog["comments_count"]
                            if comments_count != 0:
                                wbID = mblog["id"]
                                uid = mblog["user"]["id"]
                                start_comment_url = "https://weibo.com/ajax/statuses/buildComments?is_reload=1&id={}&is_show_bulletin=2&is_mix=0&count=20&uid={}"
                                yield scrapy.FormRequest(
                                    url=start_comment_url.format(wbID, uid),
                                    headers={
                                        'User-Agent': "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                                        "x-xsrf-token": "VKpz1KXPsFfsZL0v6cgau8Fl",
                                        "x-requested-with": "XMLHttpRequest",
                                    },
                                    callback=self.parse_wbComment,
                                    meta={"wbID": wbID, "uid": uid}

                                )
                elif card["card_type"] == 9:
                    mblog = card["mblog"]
                    comments_count = mblog["comments_count"]
                    if comments_count != 0:
                        wbID= mblog["id"]
                        uid = mblog["user"]["id"]
                        #print(comments_count,wbID,uid)
                        start_comment_url ="https://weibo.com/ajax/statuses/buildComments?is_reload=1&id={}&is_show_bulletin=2&is_mix=0&count=20&uid={}"
                        yield scrapy.FormRequest(
                            url=start_comment_url.format(wbID,uid),
                            headers={
                                'User-Agent': "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                                "x-xsrf-token": "VKpz1KXPsFfsZL0v6cgau8Fl",
                                "x-requested-with": "XMLHttpRequest",
                            },
                            callback=self.parse_wbComment,
                            meta={"wbID":wbID,"uid":uid}
                        )


    def parse_wbComment(self, response, **kwargs):
        print(response)
        jsonData = json.loads(response.text)
        if jsonData["ok"]==1:
            commentDatas = jsonData["data"]
            for commentData in commentDatas:
                comment = commentData["text"]
                user = commentData["user"]["name"]
                created_at = commentData["created_at"]
                items = {}
                items["评论用户"] = user
                items["评论时间"] = created_at
                items["评论内容"] = comment
                yield items
                #print(user,created_at,comment)

        if jsonData["max_id"] != 0:
            nextUrl = "https://weibo.com/ajax/statuses/buildComments?is_reload=1&id={" \
                      "}&is_show_bulletin=1&is_mix=0&max_id={}&count=20&uid={}".format(response.meta["wbID"],
                                                                                       jsonData["max_id"],
                                                                                       response.meta["uid"])
            yield scrapy.FormRequest(
                url=nextUrl,
                headers={
                    'User-Agent': "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
                    "x-xsrf-token": "VKpz1KXPsFfsZL0v6cgau8Fl",
                    "x-requested-with": "XMLHttpRequest",
                },
                callback=self.parse_wbComment,
                meta=response.meta
            )



