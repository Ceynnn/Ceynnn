import pandas as pd
from wordcloud import WordCloud
import openpyxl
import os
from PIL import Image
import numpy as np
path='词云图'
files=[path+'\\'+file for file in os.listdir(path)]
mask=np.array(Image.open('64195675.jpg'))  #词云图背景
for file in files:
    wb = openpyxl.load_workbook(file)
    ws = wb.active
    word_dict = {}
    for i in range(2, ws.max_row + 1):
        word = ws['A' + str(i)].value
        count = ws['B' + str(i)].value
        word_dict[word] = count
# 定义词云图样式
    wc = WordCloud(font_path='simhei.ttf',
               max_words=50,
               max_font_size=100,
               background_color='white',
               mask=mask
               )

    wc.generate_from_frequencies(word_dict)
    new_file=file.split('\\')[1][:4]
    wc.to_file(f'词云图\\{new_file}.png')


