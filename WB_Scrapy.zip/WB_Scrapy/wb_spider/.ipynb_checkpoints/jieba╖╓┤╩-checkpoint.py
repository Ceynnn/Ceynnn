import jieba
import pandas as pd
import re
#import openpyxl
excel_file = pd.read_excel('评论数据.xlsx')

excel_file.to_csv('pl.txt', sep=' ', index=False)
excel_file['这个微博是四年前就不用的，在用的是河南广播电视台，正常播报着。'].to_csv('pl.txt', sep=' ', index=False)
file=open('pl.txt','r',encoding='utf-8')
txt=file.read()
#fil = re.sub(u'^[\u4E00-\u9FFF]+$',txt)
c = re.sub('<.*?>', '', txt)
#print(c)
words=jieba.lcut(c)
file.close()
#print(words)
words_dict={}  #存储词及词出现的次数
for word in words:
    if len(word)==1:#构不成词,跳过
        continue
    else:
        if word in words_dict:
            words_dict[word]+=1  #如果词在字典中存在,累加
        else:
            words_dict[word]=1 #首次出现
words_dict_sort=sorted(words_dict.items(),key=lambda x:x[1],reverse=True)
#print(words_dict_sort)
stop_word=[]
for word in stop_word:
    if word in words_dict:
        del words_dict[word]
words_dict_sort=sorted(words_dict.items(),key=lambda x:x[1],reverse=True)
print(words_dict_sort)
df=pd.DataFrame(words_dict_sort,columns=['词','次数'])
df.to_excel('词频lrcq.xlsx',index=False)
