import jieba
import pandas as pd
#import openpyxl
file=open('评论数据.xlsx','r',encoding='utf-8')
txt=file.read()
words=jieba.lcut(txt)
file.close()
#print(words)
words_dict={}  #存储词及词出现的次数
for word in words:
    if len(word)==1:#构不成词,跳过
        continue
    else:
        if word in words_dict:
            words_dict[word]+=1  #如果词在字典中存在,累加
        else:
            words_dict[word]=1 #首次出现
words_dict_sort=sorted(words_dict.items(),key=lambda x:x[1],reverse=True)
#print(words_dict_sort)
stop_word=[]
for word in stop_word:
    if word in words_dict:
        del words_dict[word]
words_dict_sort=sorted(words_dict.items(),key=lambda x:x[1],reverse=True)
print(words_dict_sort)
df=pd.DataFrame(words_dict_sort[0:15],columns=['词','次数'])
df.to_excel('词频1.xlsx',index=False)
# wb=openpyxl.Workbook()
# sheet=wb.active
# sheet.append(['词','次数'])
# for i in words_dict_sort[0:15]:
#
#     sheet.append(i)
# wb.save('词频1.xlsx')

